---------------------------------------------------------------------------------
Pedro Emanuel Alburquerque e Baptista dos Santos, n.� 070221158
Zulmira Ceita, n� 052206031
---------------------------------------------------------------------------------
Escola Superior de Tecnologia de Set�bal - Instituto Polit�cnico de Set�bal
Curso: Licenciatura em Engenharia Inform�tica
Unidade Curricular: Intelig�ncia Artificial
Docentes:
Prof. Joaquim Filipe
Eng. C�dric Grueau
Projecto 1 - Solit�rio
---------------------------------------------------------------------------------
Neste pacote pode encontrar:
- Pasta Projecto1Workspace - Pasta com o Workspace do Eclipse que cont�m o projecto em que foi desenvolvido o projecto 1 da unidade curricular que cont�m o c�digo separado em 3 ficheiros segundo o que foi pedido no enunciado
- Manual T�cnico.doc e Manual T�cnico.pdf - Ficheiros em DOC e PDF que cont�m o Manual T�cnico do Projecto
- Manual de Utilizador.doc e Manual de Utilizador.pdf - Ficheiros em DOC e PDF que cont�m o Manual de Utilizador do Projecto
- Problemas.dat - Ficheiro com os 7 casos de estudo descritos no enunciado do projecto
- Solucoes.dat - Ficheiro com o output de diversas situa��es estudadas aquando do desenvolvimento do projecto

Qualquer d�vida e/ou esclarecimento � favor contactar:
petersaints@gmail.com
zulmira.a.c@gmail.com
